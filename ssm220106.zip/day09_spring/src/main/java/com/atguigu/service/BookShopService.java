package com.atguigu.service;

public interface BookShopService {
    public void purchase(String username,String isbn);
}
